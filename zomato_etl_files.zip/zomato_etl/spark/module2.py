
from pyspark.shell import sc
from datetime import datetime
from pyspark.sql import SparkSession
import logging


def result_log(log_data):
    logr = logging.getLogger('mod2')
    logging.basicConfig(level=logging.INFO, format='%(message)s', filename='/home/talentum/zomato_etl/logs/module_2_status.log', filemode='w')
    logr.info(log_data)
    logging.shutdown()


if __name__ =='__main__':

    spark = SparkSession.builder.master('yarn').enableHiveSupport().getOrCreate()

    start_time = str(datetime.now().time())
    job_step = "creating-and-loading-in-zomato-table"
    app_id = spark.sparkContext.applicationId  # sc.application_id
    user = sc.sparkUser()

    #  log_file location
    jsontocsv_status_location = "/home/talentum/zomato_etl/logs"

    # # log file writing
    try:
        # log file writing
        log = app_id + " " + job_step + " " + start_time + " " + "NA" + " " + "RUNNING"
        result_log(log)

        # file_writer = open(jsontocsv_status_location + "/module_2_status.log", 'w')
        # file_writer.write(app_id + "\t" + job_step + "\t" + start_timestamp + "\t" + end_timestamp + "\t" + "RUNNING")
        # file_writer.close()

        # hdfs access

        # Gateway

        hadoop = sc._jvm.org.apache.hadoop
        fs = hadoop.fs.FileSystem
        conf = hadoop.conf.Configuration()
        path = hadoop.fs.Path
        hdfs = fs.get(conf)

        # hdfs_path

        file_path = path("/user/talentum/zomato_etl_shruti_gupta/zomato_ext/zomato")

        # creation of tables

        spark.sql("use shruti_database")

        spark.sql("""CREATE external TABLE IF NOT EXISTS  shruti_database.zomato
        (Restaurant_ID INT,
        Restaurant_Name STRING,Country_Code INT,City STRING, Address STRING,Locality STRING,Locality_Verbose STRING,Longitude 
        STRING,Latitude STRING,Cuisines STRING,Average_Cost_for_two INT,Currency STRING,Has_Table_booking INT,Has_Online_delivery
        INT,Is_delivering_now INT,Switch_to_order_menu INT,Price_range INT,Aggregate_rating STRING,Rating_text STRING,Votes STRING)
        PARTITIONED BY ( filedate int ) ROW FORMAT DELIMITED fields terminated by '\t' LOCATION '/user/talentum/zomato_etl_shruti_gupta/zomato_ext/zomato'
        stored as textfile""")

        # hdfs files (Loading data)

        hdfs_file_path = hdfs.listStatus(file_path)
        files = [i.getPath().getName() for i in hdfs_file_path]
        if not "filedate" in hdfs_file_path[0].getPath().getName():
            files_in_hdfs = [str(i.getPath().getName().split('_')[1]) for i in hdfs_file_path]
            print(files_in_hdfs)
            # print(files_in_hdfs)
            for i in files_in_hdfs:
                j = ''.join(i.split('-'))
                spark.sql("""LOAD DATA INPATH '/user/talentum/zomato_etl_shruti_gupta/zomato_ext/zomato/zomato_{}'
                    OVERWRITE INTO TABLE zomato PARTITION (filedate={})""".format(i, j))
        else:
            print("**** OOPS!!! CANNOT PARTITIONED ON EXISTED PARTITION  ****")
    except(IOError, IndexError, EOFError):

        print("*************************OOPS FAILED!!!!*****************************************")
        log = app_id + " " + job_step + " " + start_time + " " + "NA" + " " + "FAILED"
        result_log(log)
    else:
        log = app_id + " " + job_step + " " + start_time + " " + str(datetime.now().time()) + " " + "SUCCESS"
        result_log(log)
        print("""*********************SUCCESSFUL!!!*******************""")
