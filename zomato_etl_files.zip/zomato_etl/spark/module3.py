
from datetime import datetime
from pyspark.sql import SparkSession
import sys
import logging
from pyspark.shell import sc


def result_log(log_data):
    logr = logging.getLogger('mod3')
    logging.basicConfig(level=logging.INFO, format='%(message)s', filename='/home/talentum/zomato_etl/logs/module_3_status.log', filemode='w')
    logr.info(log_data)
    logging.shutdown()


if __name__ =='__main__':

    spark = SparkSession.builder.master('yarn').enableHiveSupport().getOrCreate()
    start_time= str(datetime.now().time())
    job_step = "Creating-dim_country-and-creating-zomato_summary-with-loading-data "
    app_id = spark.sparkContext.applicationId  # sc.applicatio_id
    user = sc.sparkUser()

    #  log_file location
    jsontocsv_status_location = "/home/talentum/zomato_etl/logs"

    # # log file writing
    try:
        log = app_id + " " + job_step + " " + start_time + " " + "NA" + " " + "RUNNING"
        result_log(log)

        # Gateway

        hadoop = sc._jvm.org.apache.hadoop
        fs = hadoop.fs.FileSystem
        conf = hadoop.conf.Configuration()
        path = hadoop.fs.Path
        hdfs = fs.get(conf)



        spark.sql("use shruti_database")

        spark.sql("""CREATE TABLE  IF NOT EXISTS shruti_database.dim_country(Country_Code int,Country string) ROW FORMAT DELIMITED
        fields terminated by '\t' stored as textfile
        """)

        spark.sql("""ALTER TABLE dim_country 
        SET LOCATION '/user/talentum/zomato_etl_shruti_gupta/zomato_ext/zomato/dim_country'
        """)

        spark.sql(
            "LOAD DATA LOCAL INPATH '/home/talentum/zomato_etl/source/csv/country_code1.csv' OVERWRITE INTO TABLE dim_country")

        spark.sql("""CREATE TABLE IF NOT EXISTS zomato_summary(Restaurant_ID INT,Restaurant_Name STRING,Country_Code INT,City STRING, 
        Address STRING,Locality STRING,Locality_Verbose STRING,Longitude STRING,Latitude STRING,Cuisines STRING,Average_Cost_for_two INT,
        Currency STRING,Has_Table_booking INT,Has_Online_delivery INT,Is_delivering_now INT,Switch_to_order_menu INT,Price_range INT,
        Aggregate_rating STRING,Rating_text STRING,Votes STRING, m_rating_colour STRING, m_cuisines STRING, create_datetime TIMESTAMP,
         user_id STRING)  PARTITIONED BY ( p_filedate INT, p_country_name STRING ) stored as ORC""")

        if (len(sys.argv)>1):
            spark.sql("""INSERT OVERWRITE table shruti_database.zomato_summary partition(p_filedate='{}',p_country_name='{}')SELECT s.restaurant_id,
        nvl( s.restaurant_name,'NA'),s.country_code,nvl(s.city, 'NA'),nvl(s.address, 'NA'),nvl( s.locality,'NA'),nvl(s.locality_verbose,'NA'),
        nvl( s.longitude, 'NA'), nvl( s.latitude, 'NA'), nvl(s.cuisines,'NA'),s.average_cost_for_two,nvl(s.currency,'NA'),s.has_table_booking,
    s.has_online_delivery,s.is_delivering_now,s.switch_to_order_menu,s.price_range,nvl(s.aggregate_rating,'NA'),nvl(s.rating_text,'NA'),
        nvl(s.votes,'NA'),case when s.cuisines like '%Indian%'or s.cuisines like '%Andhra%' or s.cuisines like '%Hyderabadi%' or
        s.cuisines like '%Goan%' or s.cuisines like '%Bengali%' or s.cuisines like '%Bihari%' or s.cuisines like '%Chettinad%'
        or s.cuisines like  '%Gujarati%' or s.cuisines like '%Rajasthani%' or s.cuisines like  '%Kerala%' or s.cuisines like
        '%Maharashtrian%' or s.cuisines like '%Mangalorean%' or s.cuisines like '%Mithai%'or s.cuisines like '%Mughlai%' then
        'Indian' else 'World Cuisines' end as m_cuisines, case when s.aggregate_rating between 1.9 and 2.4 and s.rating_text = 'Poor'
        then 'Red' when s.aggregate_rating between 2.5 and 3.4 and s.rating_text='Average' then 'Amber' when s.aggregate_rating
        between 3.5 and 3.9 and s.rating_text='Good' then 'Light Green' when s.aggregate_rating between 4.0 and 4.4 and
        s.rating_text='Very Good' then 'Green' when s.aggregate_rating between 4.5 and 5 and s.rating_text='Excellent' then
        'Gold' when s.aggregate_rating = 0 and s.rating_text='Not rated' then 'NA'  end as m_rating_colour,
        from_unixtime(unix_timestamp()),'talentum' from shruti_database.zomato s,
        shruti_database.dim_country d where s.country_code = d.country_code""".format(sys.argv[1], sys.argv[2]))

        # ,s.filedate='20210526',d.country='India'


        else:

            spark.sql("set hive.exec.dynamic.partition=true")
            spark.sql("set hive.exec.dynamic.partition.mode=nonstrict")
            spark.sql("""INSERT OVERWRITE table shruti_database.zomato_summary partition(p_filedate,p_country_name)SELECT s.restaurant_id,
            nvl( s.restaurant_name,'NA'),s.country_code,nvl(s.city, 'NA'),nvl(s.address, 'NA'),nvl( s.locality,'NA'),nvl(s.locality_verbose,'NA'),
            nvl( s.longitude, 'NA'), nvl( s.latitude, 'NA'), nvl(s.cuisines,'NA'),s.average_cost_for_two,nvl(s.currency,'NA'),s.has_table_booking,
            s.has_online_delivery,s.is_delivering_now,s.switch_to_order_menu,s.price_range,nvl(s.aggregate_rating,'NA'),nvl(s.rating_text,'NA'),
            nvl(s.votes,'NA'),case when s.cuisines like '%Indian%'or s.cuisines like '%Andhra%' or s.cuisines like '%Hyderabadi%' or
            s.cuisines like '%Goan%' or s.cuisines like '%Bengali%' or s.cuisines like '%Bihari%' or s.cuisines like '%Chettinad%' 
            or s.cuisines like  '%Gujarati%' or s.cuisines like '%Rajasthani%' or s.cuisines like  '%Kerala%' or s.cuisines like 
            '%Maharashtrian%' or s.cuisines like '%Mangalorean%' or s.cuisines like '%Mithai%'or s.cuisines like '%Mughlai%' then
            'Indian' else 'World Cuisines' end as m_cuisines, case when s.aggregate_rating between 1.9 and 2.4 and s.rating_text = 'Poor'
            then 'Red' when s.aggregate_rating between 2.5 and 3.4 and s.rating_text='Average' then 'Amber' when s.aggregate_rating
            between 3.5 and 3.9 and s.rating_text='Good' then 'Light Green' when s.aggregate_rating between 4.0 and 4.4 and 
            s.rating_text='Very Good' then 'Green' when s.aggregate_rating between 4.5 and 5 and s.rating_text='Excellent' then
            'Gold' when s.aggregate_rating = 0 and s.rating_text='Not rated' then 'NA'  end as m_rating_colour, 
            from_unixtime(unix_timestamp()),'talentum',s.filedate,nvl(d.country,'NA') from shruti_database.zomato s, 
            shruti_database.dim_country d where s.country_code = d.country_code""")
        spark.sql("INSERT OVERWRITE TABLE zomato_summary SELECT DISTINCT * FROM zomato_summary")
    except(IOError, IndexError, EOFError):

        print("*************************OOPS EXECUTION FAILED, TRY AGAIN!!!!*****************************************")
        log = app_id + " " + job_step + " " + start_time + " " + "NA" + " " + "FAILED"
        result_log(log)

    else:
        log = app_id + " " + job_step + " " + start_time + " " + str(datetime.now().time()) + " " + "SUCCESS"
        result_log(log)
        print("""*********************CONGRATS!!!!! SUCCESSFUL!!!*******************""")
