

from datetime import datetime, timedelta
import os
from pyspark.shell import sc
from pyspark.sql import *
import pyspark.sql.functions as F
import logging


def result_log(log_data):
    logr = logging.getLogger('mod1')
    logging.basicConfig(level=logging.INFO, format='%(message)s', filename='/home/talentum/zomato_etl/logs/module_1_status.log', filemode='w')
    logr.info(log_data)
    logging.shutdown()

if __name__ =='__main__':
    spark = SparkSession.builder.master('yarn').enableHiveSupport().getOrCreate()


    start_time = str(datetime.now().time())
    job_step = "JSON-TO-CSV"
    app_id = spark.sparkContext.applicationId  # sc.application_id
    user = sc.sparkUser()

    # hdfs access


    # Gateway
    hadoop = sc._jvm.org.apache.hadoop
    fs = hadoop.fs.FileSystem
    conf = hadoop.conf.Configuration()
    path = hadoop.fs.Path
    hdfs = fs.get(conf)

    # hdfs_path
    shruti_host = "/user/talentum/"
    shruti_home_hdfs = shruti_host + "zomato_etl_shruti_gupta"

    try:
        if not (hdfs.exists(path(shruti_home_hdfs))):
            hdfs.mkdirs(path(shruti_home_hdfs))
        if not (hdfs.exists(path(shruti_home_hdfs + "/zomato_ext"))):
            hdfs.mkdirs(path(shruti_home_hdfs + "/zomato_ext"))
        if not (hdfs.exists(path(shruti_home_hdfs + "/zomato_ext/zomato"))):
            hdfs.mkdirs(path(shruti_home_hdfs + "/zomato_ext/zomato"))

        print("""***********************Hello, "+{}+"!**********************
            ***************	Beginning Processing!*************""".format(user))

        #  log_file location
        jsontocsv_status_location = "/home/talentum/zomato_etl/logs"

        # log file writing
        log = app_id + " " + job_step + " " + start_time + " " + "NA" + " " + "RUNNING"
        result_log(log)

        # file_writer = open(jsontocsv_status_location + "/module_1_status.log", 'w')
        # file_writer.write(app_id + "\t" + job_step + "\t" + start_timestamp + "\t" + end_timestamp + "\t" + "RUNNING")
        # file_writer.close()
        # json file_path
        file_path = "/home/talentum/zomato_etl/source/json/"

        # Date Incrementation

        date_increment = datetime.now().date()
        # reading and writing files

        file_path_loop = os.listdir(file_path)

        if len(file_path_loop) != 0:

            for i in file_path_loop:
                print("*************CONVERSION {} to CSV FORMAT********************".format(i))
                df = spark.read.format("json").option("inferSchema", "true").load(
                    "file:///home/talentum/zomato_etl/source/json/{}".format(i))
                new_df = df.select(F.explode(df.restaurants.restaurant))
                final_df = new_df.select(new_df.col.R.res_id.alias('Restaurant_ID'),
                                         new_df.col['name'].alias('Restaurant_Name'),
                                         new_df.col.location.country_id.alias('Country_Code'),
                                         new_df.col.location.city.alias("City"),
                                         new_df.col.location.address.alias('Address'),
                                         new_df.col.location.locality.alias('Locality'),
                                         new_df.col.location.locality_verbose.alias('Locality_Verbose'),
                                         new_df.col.location.longitude.alias('Longitude'),
                                         new_df.col.location.latitude.alias('Latitude'),
                                         new_df.col.cuisines.alias("Cuisines"),
                                         new_df.col.average_cost_for_two.alias("Average_Cost_For_Two"),
                                         new_df.col.currency.alias("Currency"),
                                         new_df.col.has_table_booking.alias("Has_Table_Booking"),
                                         new_df.col.has_online_delivery.alias("Has_Online_Delivery"),
                                         new_df.col.is_delivering_now.alias("Is_Delivering_Now"),
                                         new_df.col.switch_to_order_menu.alias("Switch_To_Order_Menu"),
                                         new_df.col.price_range.alias("Price_Range"),
                                         new_df.col.user_rating.aggregate_rating.alias("Aggregate_Rating"),
                                         new_df.col.user_rating.rating_text.alias("Rating_Text"),
                                         new_df.col.user_rating.votes.alias("Votes")
                                         )

                final_df.write.format('csv').options(delimiter='\t').save(
                    'file:///home/talentum/zomato_etl/source/csv/{}'.format(i))
                os.system(
                    'mv /home/talentum/zomato_etl/source/csv/{}/part* /home/talentum/zomato_etl/source/csv/zomato_{}'.format(
                        i,
                        str(date_increment)))

                os.system(
                    'mv /home/talentum/zomato_etl/source/json/{} /home/talentum/zomato_etl/archive'.format(i))
                # copy from local to hdfs
                hdfs.copyFromLocalFile(path('/home/talentum/zomato_etl/source/csv/zomato_{}'.format(date_increment)),
                                       path('/user/talentum/zomato_etl_shruti_gupta/zomato_ext/zomato'))
                # date incrementation
                date_increment = date_increment + timedelta(1)
        else:
            print("**** OOPS!!! NO FILES FOUND FOR CONVERSION. KINDLY UPLOAD DATA FIRST!!! ****")
            pass
    except(IOError, IndexError, EOFError):
        print("*************************OOPS FAILED!!!!*****************************************")
        log = app_id + " " + job_step + " " + start_time + " " + "NA" + " " + "FAILED"
        result_log(log)
    else:
        log = app_id + " " + job_step + " " + start_time + " " + str(datetime.now().time()) + " " + "SUCCESS"
        result_log(log)

        print("""*********************SUCCESSFUL!!!*******************""")
