#!/bin/bash

#Initialising default variables
file_status_path=/home/talentum/zomato_etl/logs/module_1_status.log
mailing_address="shruti.gupta.training@gmail.com"
module_tag="Module1"

#Mail function to send mail on status update_connect
function user_notification(){
	module_tag=$1
	module_status=$2
	module_initialising=$3
	module_completiontime=$4
	module_id=$5
	echo -e "Subject: $module_tag Status Update: ID-$module_id\n\n$module_tag has accomplished execution!\nStatus:\t\t$module_status\nStart-Time:\t$module_initialising\nEnd-Time:\t$module_completiontime\nFor more details, check zomato_etl/logs folder" | /usr/sbin/sendmail $mailing_address
}

#Spark submit function to call the spark submit command and update the status

function execution_section() {

	echo "Task1 - CONVERSION OF JSON TO CSV Launching"
	spark_submit_value='/home/talentum/spark/bin/spark-submit --master yarn --num-executors 2 --executor-memory 1g /home/talentum/zomato_etl/spark/module1.py'
        echo "Task Accomplished!!!!"
	current_date=$(date +"%Y%m%d")
	$spark_submit_value 
	
	update_connect "$spark_submit_value"
}

#Update function to update the status log and call the mail function
function update_connect() {

	spark_value=$1

	declare -a revised_value
	if test -f "$file_status_path"; then

		revised_value=(`cat $file_status_path`)

		#Beeline command to load status log into the zomato_summary_log table
		beeline -u jdbc:hive2://localhost:10000 -n hiveuser -p Hive@123 org.apache.hive.jdbc.HiveDriver -e "insert into shruti_database.zomato_summary_log values('${revised_value[0]}','${revised_value[1]}','$spark_value','${revised_value[2]}','${revised_value[3]}','${revised_value[4]}');"
echo ${revised_value[2]} ${revised_value[3]}

		if [ ${revised_value[4]}="SUCCESSFUL" ]; then {
			user_notification $module_tag "SUCCESS" ${revised_value[2]} ${revised_value[3]} ${revised_value[0]}
		}
		elif [ ${revised_value[4]}="FAILED" ]; then {
			user_notification $module_tag "FAILED" ${revised_value[2]} ${revised_value[3]} ${revised_value[0]}
		}
		elif [ ${revised_value[4]}="RUNNING" ]; then {
			user_notification $module_tag "Unsuccessfully RUNNING" ${revised_value[2]} ${revised_value[3]} ${revised_value[0]}
		}
		else {
			user_notification $module_tag "Unknown" ${revised_value[2]} ${revised_value[3]} ${revised_value[0]}
		}
		fi

		else
			echo "Unable to get updated instance"
			echo "Could not update json to csv"
		fi
}

#Array to hold status.log file tag
declare -a file_value
if test -f "$file_status_path"; then

	file_value=(`cat $file_status_path`)

	#Case to run application based on running instance check
	case "${file_value[4]}" in
		"SUCCESS")
			execution_section
			;;
		"FAILED")
			echo "Previous Instance failure occured"
			user_notification $module_tag "Previous Instance failure occured" ${file_value[2]} ${file_value[3]} ${file_value[0]}
			execution_section
			;;                                                
		"RUNNING")                                                
			echo "Running in progress"                                                
			echo "Terminating"                                                
			user_notification $module_tag "Running in progress" ${file_value[2]} ${file_value[3]} ${file_value[0]}                                               
			;;                                                
		*)                                                
			user_notification $module_tag "Something went wrong, Removing status logs!" ${file_value[2]} ${file_value[3]} ${file_value[0]}                                               
			echo "Something went wrong, restarting this module!"                                                
			echo "Removing corrupted status log"                                                
			rm "$file_status_path"                                                
			execution_section                                                
			;;                                                
	esac                                                
else                                                
	echo "module_1_status file not found, Running Spark Application"                                                
	execution_section                                                
fi

echo $? $current_date $module_tag >> execution_status.txt 
